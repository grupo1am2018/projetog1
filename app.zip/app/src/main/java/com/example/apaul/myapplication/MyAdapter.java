package com.example.apaul.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

/**
 * Created by apaul on 01/05/2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    String[] nomeJogador;
    Bitmap[] fotoJogador;
    Context context;

    public MyAdapter(String[] nomeJogador, Context context) {
        this.nomeJogador = nomeJogador;
        //this.fotoJogador = fotoJogador;
        this.context = context;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.jogador, parent, false);
        MyViewHolder viewHolder = new MyViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        Picasso.with(context).load("https://platform-static-files.s3.amazonaws.com/premierleague/photos/players/250x250/p62398.png").resize(150,150).into(holder.logo);
        holder.name.setText(nomeJogador[position]);
        holder.logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "This is: " + nomeJogador[position], Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return nomeJogador.length;
    }
}